/**
 * Copyright (C) 2023 Carnegie Mellon University
 *
 * This file is part of the Mixnet course project developed for
 * the Computer Networks course (15-441/641) taught at Carnegie
 * Mellon University.
 *
 * No part of the Mixnet project may be copied and/or distributed
 * without the express permission of the 15-441/641 course staff.
 */

 
#include "node.h"
#include "connection.h"
#include "packet.h"
#include "utils.h"
#include "routing.h"
#include "stp.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define INF 0xFFFF

/**
 * @brief This function is entrance point into each node
 * 
 * @param handle 
 * @param keep_running 
 * @param c 
 */
void run_node(void *const handle,
              volatile bool *const keep_running,
              const struct mixnet_node_config config) {

    (void) config;
    (void) handle;
    // bool verbose = false;
    // Initialize Node from the handle
    struct Node* node = malloc(sizeof(struct Node));
    node->num_neighbors = config.num_neighbors;
    node->total_nodes = 0;
    node->neighbors_addy = malloc(sizeof(mixnet_address) * config.num_neighbors);
    node->neighbors_blocked = malloc(sizeof(bool) * config.num_neighbors);
    node->neighbors_cost = config.link_costs;
    node->visitedCount = 0;
    
    // for (int i = 0; i < node->num_neighbors; i ++){
    //     printf(" idx:%d , cost  :%d \n", i, node->neighbors_cost[i]);
    // }

    if (node->neighbors_addy == NULL || node->neighbors_blocked == NULL) {
        exit(1);
    }
    for (int i = 0; i < config.num_neighbors; i++) {
        node->neighbors_addy[i] = INVALID_MIXADDR;
    }
    
    for (int i = 0; i < config.num_neighbors; i++) {
        node->neighbors_blocked[i] = true; // initialize all to un-blocked
    }

    node->root_addr = config.node_addr; // I AM THE ROOT! 
    node->my_addr = config.node_addr;
    node->next_hop = config.node_addr; // self
    node->path_len = 0;

    // printf("NODE :#%d initialized! \n", node->my_addr);
    


    for (uint16_t i = 0; i < (1<<16)-1; i++) {
        node->visited[i] = false;
        node->distance[i] = UINT16_MAX;
        node->prev_neighbor[i] = INVALID_MIXADDR; //? question mark? 
    }

    node->distance[node->my_addr] = 0; // distance to self == 0
    node->visited[node->my_addr] = false; // node->visited self
    node->smallestindex = node->my_addr;


    send_STP(handle, node); // SEND STP 
    // printf("Set up neighbours");
    // print_node(node);
    
    node->re_election_time = get_time_in_ms();
    node->heartbeat_time = get_time_in_ms();
    node->lsa_time = get_time_in_ms();
    // printf("Starting time: %d \n", start_time);

    //allocate chunk of memory for buffer
    mixnet_packet *packet_buffer =
        (mixnet_packet *)malloc(sizeof(MAX_MIXNET_PACKET_SIZE));

    // printf("Packet memory initialized\n");

    if (packet_buffer == NULL) {
        exit(1);
    }
    uint16_t num_user_packets = 0;
    uint16_t sent_to_users = 0;
    // uint8_t node_id = node->my_addr; 

    while(*keep_running) {
        //check if keep running is true
        if (!(*keep_running)) {
            printf("Keep running not true anymore. break!");
            break;
        }

        uint8_t port;
        bool recv = mixnet_recv(handle, &port, &packet_buffer);

        // receiving from all my neighbors
        // uint32_t curr_time = get_time_in_ms();

        // i'm root, and its time to send a root hello
        if (node->root_addr == node->my_addr && get_time_in_ms() - node->heartbeat_time >= config.root_hello_interval_ms) {
            send_STP(handle, node);
            node->heartbeat_time = get_time_in_ms();
        }

        //SENDING OUT LSA's every _(?) root hellos
        if (get_time_in_ms() - node->lsa_time >= config.root_hello_interval_ms*15) {
            send_out_LSA(handle, node);
            node->lsa_time = get_time_in_ms();
        }

        // hey, i'm not the root, but i haven't got a root hello in a while. i'm root now!
        if (node->root_addr != node->my_addr && get_time_in_ms() - node->re_election_time >= config.reelection_interval_ms) {
            node->root_addr = node->my_addr;
            node->path_len = 0;
            node->next_hop = node->my_addr;
            send_STP(handle, node);
            for (uint8_t i = 0; i < node->num_neighbors; i++) {
                node->neighbors_blocked[i] = false;
            }
            node->re_election_time = get_time_in_ms();
        }
    
        // we received something. 
        if (recv) {
            if (packet_buffer->type == PACKET_TYPE_STP || packet_buffer->type == PACKET_TYPE_FLOOD) {
                // Copying Payload over for STP/Flood Types
                mixnet_packet_stp *update = (mixnet_packet_stp *)malloc(sizeof(mixnet_packet_stp));
                memcpy((void *)update, (void *)packet_buffer->payload,  sizeof(mixnet_packet_stp));

                if (packet_buffer->type == PACKET_TYPE_STP){
                    handle_STP(node, handle, update, packet_buffer, port);
                }
                else if (packet_buffer->type == PACKET_TYPE_FLOOD){
                    if (port == node->num_neighbors) {
                        num_user_packets++;
                        send_FLOOD(handle, node, port);
                        } 
                    else if (!node->neighbors_blocked[port]){
                        send_FLOOD(handle, node, port);
                        }
                }
            }
            // LSA Packets Handling
            else if (packet_buffer->type == PACKET_TYPE_LSA){
                // printf("LSA Packet!\n");
                // If received from unblocked ports and not from user   
                if (!node->neighbors_blocked[port] && port != node->num_neighbors){
                    receive_and_send_LSA(packet_buffer, handle, node, port);
                    // print_node(node, true);
                }
                
                // print_node(node, true);
            }
            // TODO : Packets that uses Routing Headers
            else {
                assert(packet_buffer->type == PACKET_TYPE_DATA || packet_buffer->type == PACKET_TYPE_PING);
                
                if (packet_buffer->type == PACKET_TYPE_DATA){
                    unsigned long total_size = packet_buffer->total_size;
                    mixnet_packet_routing_header* header = (mixnet_packet_routing_header* ) &packet_buffer->payload;
                    unsigned long data_size = total_size - sizeof(mixnet_packet) - sizeof(mixnet_packet_routing_header) - header->route_length * sizeof(mixnet_address);
                    
                    //if user sent packet, route length will be 0, need to compute route adn intialize routing header + copy packet data after
                    
                    if (port == node->num_neighbors){
                        // print_globalgraph(node);
                        num_user_packets++;
                        // print_globalgraph(node);
                        // print_node(node, true);

                        dijkstra(node, false);
                        char* data = (char*) malloc(data_size);
                        //can i just cpy max_mixnet_data size over? (size == 8?)
                        memcpy(data, (char*)header + 2 * sizeof(mixnet_address) + 2 * sizeof(uint16_t), data_size);

                        mixnet_address** best_paths = node->global_best_path[header->dst_address];
                        mixnet_packet* final_data_packet = initialize_DATA_packet(best_paths, header->dst_address, header->src_address, data, data_size);
                        //find hope index and route length
                        mixnet_packet_routing_header* new_header = (mixnet_packet_routing_header*) &final_data_packet->payload;

                        // print_routing_header(new_header);

                        uint16_t nextport = find_next_port(new_header, node);
                        
                        assert(nextport != INVALID_MIXADDR);
                        mixnet_send(handle, nextport, final_data_packet);
                        
                    } else {
                        // printf("DATA Received on!\n");
                        // print_routing_header(header);
                        //i've reached -> am done, thanks. send to my own user
                        if (node->my_addr == header->dst_address){
                            assert(header->hop_index == header->route_length);
                            // printf("Routed Successfully Sending to Node#%d's User\n", node->my_addr);
                            mixnet_send(handle, node->num_neighbors, packet_buffer);
                            sent_to_users++;
                        }
                        else {
                            //else, send to next one in the route_length and increment hop_idx
                            header->hop_index ++;
                            // printf("Hop Index incremented! \n");
                            // print_routing_header(header);
                            assert(header->hop_index > 0);
                            uint16_t nextport = find_next_port(header, node);
                            assert(nextport != INVALID_MIXADDR);
                            mixnet_send(handle, nextport, packet_buffer);
                        }
                    }
                }
                else if (packet_buffer->type == PACKET_TYPE_PING){

                    // if (port == node->num_neighbors){
                    //     //set up my own ping packet
                    //     mixnet_address src_address, dest_address;
                    //     memcpy(&src_address, packet_buffer->payload, sizeof(mixnet_address));
                    //     memcpy(&dest_address, packet_buffer->payload + sizeof(mixnet_address), sizeof(mixnet_address));
                    //     char* data = (char*) malloc(MAX_MIXNET_DATA_SIZE);
                        
                    //     //can i just cpy max_mixnet_data size over?
                    //     memcpy(data, packet_buffer->payload + 2 * sizeof(mixnet_address) + 2 * sizeof(uint16_t), MAX_MIXNET_DATA_SIZE);

                    //     mixnet_address** best_paths = node->global_best_path[dest_address];
                        
                    //     mixnet_packet* final_ping_packet = initialize_PING_packet(best_paths, dest_address, src_address);


                    // }

                    // else {

                    //     //rmbr check destination and then send back also

                    // }


                // }

                // printf("Received Data/Ping Packet! \n");
                }

            }
        }
    }
    // // print_graph(node);
    // printf("Node[#%d] Stats: \n | Received User Packets: %d  | Sent To User: %d, Node[#%d] stopped running \n", node->my_addr, num_user_packets, sent_to_users, node->my_addr);
    // print_node(node, false);
}
